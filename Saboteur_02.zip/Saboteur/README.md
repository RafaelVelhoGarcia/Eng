# Saboteur

## Instruções de execução

1. `virtualenv venv`

2. Ativar a venv (em `venv/bin/activate`)

3. Rode `pip install -r requirements.txt`.

4. Para rodar a interface, execute `python3 src/interface.py`.
