from player_interface import PlayerInterface

if __name__ == "__main__":
    PlayerInterface()
