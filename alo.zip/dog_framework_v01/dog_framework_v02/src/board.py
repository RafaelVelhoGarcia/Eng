from card import *
from collections import deque

class Board:
    def __init__(self):
        self.board = [[None for _ in range(9)] for _ in range(5)]
        self.matrix = [[0 for _ in range(27)] for _ in range(15)]

    def clear(self):
        for i in range(5):
            for j in range(9):
                self.board[i][j] = None
        for i in range(15):
            for j in range(27):
                self.matrix[i][j] = 0

    def get_card_from_position(self, position):
        return self.board[position[0]][position[1]]

    def set_card_to_position(self, card, position):
        self.board[position[0]][position[1]] = card
        self.update_matrix(card, position)

    def remove_card_from_position(self, position):
        self.update_matrix(self.get_card_from_position(position), position, 0)
        self.board[position[0]][position[1]] = None

    def check_adjacent_cards(self, card, row, col):
        has_adjacent_path = False
        if col < 8:
            adjacent_card = self.board[row][col+1]
            if adjacent_card != None:
                if adjacent_card.left() != card.right():
                    return False
                else:
                    has_adjacent_path = True
        if row > 0:
            adjacent_card = self.board[row-1][col]
            if adjacent_card != None:
                if adjacent_card.bottom() != card.top():
                    return False
                else:
                    has_adjacent_path = True
        if col > 0 :
            adjacent_card = self.board[row][col-1]
            if adjacent_card != None:
                if adjacent_card.right() != card.left():
                    return False
                else:
                    has_adjacent_path = True
        if row < 4:
            adjacent_card = self.board[row+1][col]
            if adjacent_card != None:
                if adjacent_card.top() != card.bottom():
                    return False
                else:
                    has_adjacent_path = True
        return has_adjacent_path

    def update_matrix(self, card, position, value=1):
        row = position[0] * 3
        col = position[1] * 3
        if card.right():
            self.matrix[row+1][col+2] = value
        if card.top():
            self.matrix[row][col+1] = value
        if card.left():
            self.matrix[row+1][col] = value
        if card.bottom():
            self.matrix[row+2][col+1] = value
        if card.center():
            self.matrix[row+1][col+1] = value

    def verify_path(self):
        print("Verificando caminho...")
        # O algoritmo abaixo foi feito usando DeepSeek
        visited = [[False] * 27 for _ in range(15)]
        queue = deque()
        start = (7, 1)
        visited[7][1] = True
        queue.append(start)

        targets = {(1, 25), (7, 25), (13, 25)}
        reached = set()

        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

        while queue:
            r, c = queue.popleft()
            
            if (r, c) in targets:
                reached.add((r, c))
                if len(reached) == 3:
                    break
            
            for dr, dc in directions:
                nr = r + dr
                nc = c + dc
                if 0 <= nr < 15 and 0 <= nc < 27:
                    if not visited[nr][nc] and self.matrix[nr][nc] == 1:
                        visited[nr][nc] = True
                        queue.append((nr, nc))

        result = []
        for target in [(1, 25), (7, 25), (13, 25)]:
            if target in reached:
                result.append(self.board[((target[0]+2)//3)-1][8])
        print("Caminho verificado!")
        return result

    def verify_path_to_target(self, position, card):
        row = position[0] * 3
        col = position[1] * 3

        targets = []
        if card.right():
            targets.append((row+1, col+3))
        if card.top():
            targets.append((row-1,col+1))
        if card.left():
            targets.append((row+1,col-1))
        if card.bottom():
            targets.append((row+3,col+1))

        visited = [[False] * 27 for _ in range(15)]
        queue = deque()
        start = (7, 1)
        visited[7][1] = True
        queue.append(start)

        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]

        while queue:
            r, c = queue.popleft()
            
            if (r, c) in targets:
                print("Caminho até o alvo válido.")
                return True
            
            for dr, dc in directions:
                nr = r + dr
                nc = c + dc
                if 0 <= nr < 15 and 0 <= nc < 27:
                    if not visited[nr][nc] and self.matrix[nr][nc] == 1:
                        visited[nr][nc] = True
                        queue.append((nr, nc))
        print("Caminho até o alvo inválido.")
        return False
