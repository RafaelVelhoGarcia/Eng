# id[0] = 0 for board selection cards
# id[1] = 0 for path cards
# id[1] = 1 for rockfall cards
# id[1] = 2 for map cards 

# id[1] = 3 for gold cards
# id[2] = 4 for coal cards

# id[0] = 1 for player selection cards
# id[1] = 0 for saboteur cards
# id[1] = 1 for repair cards

# id[0] = 2 for role cards
# id[1] = 1 for miners
# id[2] = 2 for saboteurs

# id[0] = 3 for gold nugget cards

from enum import Enum

class Card:
    def __init__(self, id):
        self.id = id            

    def get_id(self):
        return self.id

class PathCard(Card):
    def __init__(self, id, destroyable=True):
        super().__init__(id)
        self.destroyable = destroyable
        self.paths = id[2:7] #right, top, left, bottom, center
        self.rotated = False

    def is_destroyable(self):
        return self.destroyable

    def rotate(self):
        print("Rotacionando carta...")
        self.paths = self.paths[2] + self.paths[3] + self.paths[0] + self.paths[1] + self.paths[4]
        self.id = "00" + self.paths

    def left(self):
        if self.paths[2] == "1":
            return True
        else:
            return False
    def top(self):
        if self.paths[1] == "1":
            return True
        else:
            return False
    def right(self):
        if self.paths[0] == "1":
            return True
        else:
            return False
    def bottom(self):
        if self.paths[3] == "1":
            return True
        else:
            return False

    def center(self):
        if self.paths[4] == "1":
            return True
        else:
            return False

class GoalCard(PathCard):
    def __init__(self, id, gold):
        super().__init__(id, False)
        self.gold = gold
        self.revealed = False

    def has_gold(self):
        return self.gold

    def reveal(self):
        self.revealed = True
    
    def is_revealed(self):
        return self.revealed

class SabotageCard(Card):
    def __init__(self, id, tool):
        super().__init__(id)
        self.tool = tool

    def get_tool(self):
        return self.tool

class RepairCard(Card):
    def __init__(self, id, tools):
        super().__init__(id)
        self.tools = tools

    def get_tools(self):
        return self.tools

class GoldNuggetsCard(Card):
    def __init__(self, id):
        super().__init__(id)
        self.gold = int(id[1])

    def get_gold(self):
        return self.gold

class Tool(Enum):
    MINECART = 1
    LANTERN = 2
    PICKAXE = 3