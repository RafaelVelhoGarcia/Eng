import random
from card import *

class Deck:
    def __init__(self):
        self.deck = []

    def initialize(self):
        self.add_path_cards()
        self.add_map_cards()
        self.add_rockfall_cards()
        self.add_sabotage_cards()
        self.add_repair_cards()
        random.shuffle(self.deck)
        self.add_goal_cards()
        self.add_role_cards()
    
    def pop(self):
        return self.deck.pop()

    def clear(self):
        self.deck.clear()

    def size(self):
        return len(self.deck)

    def is_empty(self):
        return len(self.deck) == 0

    def add_goal_cards(self):
        gold = random.randint(0, 2)
        for i in range(3):
            if i == gold:
                gold_str = "3"
            else:
                gold_str = "4"
            self.deck.append(Deck.card_factory("0" + gold_str + "11111"))

    def add_role_cards(self):
        roles = ["1", "1", "1", "1", "2", "2"] # 4 miners, 2 saboteurs
        random.shuffle(roles)
        for i in range(5):
            self.deck.append(Card("2" + roles[i]))

    def add_gold_cards(self):
        nugget_list = []
        for i in range(4):
            nugget_list.append(3)
        for i in range(8):
            nugget_list.append(2)
        for i in range(16):
            nugget_list.append(1)

        random.shuffle(nugget_list)
        nugget_list = nugget_list[0:5]
        nugget_list.sort()

        self.deck.clear()
        for i in range(4):
            self.deck.append(GoldNuggetsCard("3" + str(nugget_list[i])))

    def add_path_cards(self):
        for i in range(4):
            self.deck.append(self.card_factory("0001011"))
        for i in range(5):
            self.deck.append(self.card_factory("0011011"))
        for i in range(5): # Substituir pra 5 depois
            self.deck.append(Deck.card_factory("0011111"))
        for i in range(5):
            self.deck.append(self.card_factory("0011101"))
        for i in range(3):
            self.deck.append(self.card_factory("0010101"))
        for i in range(4):
            self.deck.append(self.card_factory("0010011"))
        for i in range(5):
            self.deck.append(self.card_factory("0000111"))
        for i in range(4):
            self.deck.append(self.card_factory("0000010"))
        self.deck.append(self.card_factory("0001010"))
        self.deck.append(self.card_factory("0011010"))
        self.deck.append(self.card_factory("0011110"))
        self.deck.append(self.card_factory("0011100"))
        self.deck.append(self.card_factory("0010100"))
        self.deck.append(self.card_factory("0010010"))
        self.deck.append(self.card_factory("0000110"))
        self.deck.append(self.card_factory("0000100"))

    def add_map_cards(self):
        for i in range(6):
            self.deck.append(Card("02"))

    def add_rockfall_cards(self): 
        for i in range(3): # MUDAR PARA 3
            self.deck.append(Card("01"))

    def add_sabotage_cards(self):
        for i in range(3): # PADRAO - 3
            self.deck.append(Deck.card_factory("101"))
            self.deck.append(Deck.card_factory("102"))
            self.deck.append(Deck.card_factory("103"))

    def add_repair_cards(self):
        for i in range(2): #PADRAO = 2
            self.deck.append(Deck.card_factory("111"))
            self.deck.append(Deck.card_factory("112"))
            self.deck.append(Deck.card_factory("113"))
        self.deck.append(Deck.card_factory("114"))
        self.deck.append(Deck.card_factory("115"))
        self.deck.append(Deck.card_factory("116"))

    @staticmethod
    def card_factory(id):
        if id[0] == "0" and id[1] == "0":
            return PathCard(id)
        if id[0] == "0" and (id[1] == "1" or id[1] == "2"):
            return Card(id)
        if id[0] == "0" and (id[1] == "3" or id[1] == "4"):
            if id[1] == "3":
                return GoalCard(id, True)
            elif id[1] == "4":
                return GoalCard(id, False)
        
        if id[0] == "1":
            if id[1] == "0":
                if id[2] == "1":
                    return SabotageCard(id, Tool.MINECART)
                elif id[2] == "2":
                    return SabotageCard(id, Tool.LANTERN)
                elif id[2] == "3":
                    return SabotageCard(id, Tool.PICKAXE)
            
            elif id[1] == "1":
                if id[2] == "1":
                    return RepairCard(id, [Tool.MINECART])
                elif id[2] == "2":
                    return RepairCard(id, [Tool.LANTERN])
                elif id[2] == "3":
                    return RepairCard(id, [Tool.PICKAXE])

                if id[2] == "4":
                    return RepairCard(id, [Tool.MINECART, Tool.LANTERN])
                if id[2] == "5":
                    return RepairCard(id, [Tool.LANTERN, Tool.PICKAXE])
                if id[2] == "6":
                    return RepairCard(id, [Tool.MINECART, Tool.PICKAXE])
        
        if id[0] == "2":
            return Card(id)

        if id[0] == "3":
            return GoldNuggetsCard(id)

    def to_string(self):
        deck_str = []
        for i in range(len(self.deck)):
            deck_str.append(self.deck[i].get_id())
        return deck_str

    def from_string(self, deck_str):
        for i in range(len(deck_str)):
            self.deck.append(Deck.card_factory(deck_str[i]))