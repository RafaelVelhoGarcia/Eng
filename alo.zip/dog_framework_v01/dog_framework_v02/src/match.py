from player import *
import random
from enum import Enum
from card import *
from collections import deque
from deck import Deck
from board import Board

class Match:
    def __init__(self):
        self.local_player = None
        self.current_player_index = None
        self.local_player_index = None
        self.selected_card = None
        self.selected_position = None
        self.deck = Deck()
        self.players = []
        self.board = Board()
        self.move = {"action" : None, "match_status" : None, "deck" : None, "winners" : None, "card_id" : None, "player_index" : None}
        self.valid_move = False
        self.current_round = 0
        for i in range(5):
            self.players.append(Player())
        self.running = False     # Nenhuma partida em andamento
        self.ranking = []

    def get_move(self):
        return self.move

    def is_running(self):
        return self.running

    def get_players(self):
        return self.players

    def get_local_player(self):
        return self.local_player

    def get_current_round(self):
        return self.current_round

    def is_move_valid(self):
        return self.valid_move

    def reset_move(self):
        self.move = self.move = {"action" : None, "match_status" : None, "deck" : None, "winners" : None, "card_id" : None, "player_index" : None}
        self.valid_move = False

    def toggle_turn(self):
        self.current_player_index = (self.current_player_index + 1) % 5

    # Antes de realizar a troca de turno, o método abaixo gasta a carta utilizada na jogada e compra uma nova. A jogada também é marcada como válida
    def resolve_turn(self):
        self.local_player.remove_card_from_hand(self.selected_card)
        self.buy_card()
        self.valid_move = True
        self.toggle_turn()
        self.move["match_status"] = "next"

    def clear_player_hands(self):
        for player in self.players:
            player.clear_hand()

    def reset_round(self):
        print("O round está sendo resetado.")
        self.selected_card = None
        self.selected_position = None
        self.clear_player_hands()
        self.deck.clear()
        self.board.clear()
        self.move = {"action" : None, "match_status" : None, "deck" : None, "winners" : None, "card_id" : None, "player_index" : None}
        self.valid_move = False
        self.current_round += 1

    def start_round(self):
        self.reset_round()
        self.send_deck()
        self.deal_cards()

    def end_round(self, winner):
        print("O round está finalizado!")
        if winner == Role.MINER:
            self.deck.add_gold_cards()
            self.move["deck"] = self.deck.to_string()
        self.distribute_gold(self.move)

    def end(self):
        print("Fim de partida!")
        self.running = False

    def get_sabotage_cards(self):
        sabotage_cards = []
        for i in range(5):
            sabotage_cards.append(self.players[i].get_sabotage_cards())
        return sabotage_cards
    
    def get_teams_in_order(self):
        miners = []
        saboteurs = []
        for i in range(5):
            player = self.players[((self.current_player_index + i) % 5)]
            if player.get_role() == Role.SABOTEUR:
                saboteurs.append(player)
            else:
                miners.append(player)
        return miners, saboteurs

    def distribute_gold(self, move):
        print("distributing gold...")
        miners, saboteurs = self.get_teams_in_order()

        if move["winners"] == "miners":
            print("Os vencedores são os mineradores!")
            self.deck.from_string(move["deck"])
            for i in range (len(miners)):
                miners[i].add_gold(self.deck.pop().get_gold())

        if move["winners"] == "saboteurs":
            print("Os vencedores são os sabotadores!")
            if len(saboteurs) == 2:
                saboteurs[0].add_gold(3)
                saboteurs[1].add_gold(3)
            else:
                saboteurs[0].add_gold(4)

    def check_if_no_more_cards(self):
        if self.players[self.current_player_index].is_hand_empty():
            print("Todas as cartas dos jogadores acabaram!")
            self.move = {"action" : None, "match_status" : "next", "deck" : None, "winners" : "saboteurs"}
            if self.current_round > 1:
                self.move["match_status"] = "finished"
            return True
        return False

    def get_local_player_hand(self):
        return self.local_player.get_hand()

    def is_local_player_turn(self):
        return self.local_player_index == self.current_player_index

    def select_hand_position(self, hand_index):
        print(self.current_player_index)
        if self.is_local_player_turn():
            hand = self.get_local_player_hand()
            if hand_index < len(hand):
                if self.selected_card == hand[hand_index] and self.selected_card.get_id()[0:2] == "00":
                    self.selected_card.rotate()
                self.selected_card = self.get_local_player_hand()[hand_index]
                print(self.selected_card.get_id())

    def start(self, players, local_player_id):
        self.running = True     # Em progresso
        for i in range(5):
            self.players[i].initialize(players[i])
            if players[i][1] == local_player_id:
                self.local_player = self.players[i]
                self.local_player_index = int(players[i][2]) - 1

        self.players = sorted(self.players, key=lambda p: p.position)
        self.current_player_index = 0

    def send_deck(self):
        self.deck.initialize()
        self.move["action"] = "send_deck"
        self.move["match_status"] = "next"
        self.move["deck"] = self.deck.to_string()
        print("Enviando o deck embaralhado para os demais jogadores.")

    def deal_cards(self):
        print("Dando as cartas!")
        for i in range(5):
            self.players[i].set_role(Role(int(self.deck.pop().get_id()[1])))
        print("Colocando as cartas de objetivo no tabuleiro")
        self.board.set_card_to_position(self.deck.pop(), [0, 8])
        self.board.set_card_to_position(self.deck.pop(), [2, 8])
        self.board.set_card_to_position(self.deck.pop(), [4, 8])

        print("Dando as cartas para os jogadores")
        for i in range(5):
            for j in range(6):
                self.players[i].hand.append(self.deck.pop())

        print("Colocando carta inicial no tabuleiro")
        self.board.set_card_to_position(PathCard("0011111", False), [2, 0])

    def buy_card(self):
        if not self.deck.is_empty():
            self.local_player.buy_card(self.deck.pop())

    def discard(self):
        if self.is_local_player_turn() and self.selected_card != None:
            self.resolve_turn()

    def reveal_cards(self, cards):
        for c in cards:
            if not c.is_revealed():
                c.reveal()
            if c.has_gold():
                print("O ouro foi encontrado!")
                self.move["winners"] = "miners"

    def select_board_position(self, row, col):
        if self.is_local_player_turn() and self.selected_card != None:
            self.selected_position = [row, col]
            if self.selected_card.get_id()[0:2] == "00" and not self.local_player.is_blocked():
                if self.board.check_adjacent_cards(self.selected_card, row, col) and self.board.verify_path_to_target(self.selected_position, self.selected_card):
                    self.resolve_turn()
                    self.board.set_card_to_position(self.selected_card, self.selected_position)
                    print("A carta foi colocada no tabuleiro!")

                    self.reveal_cards(self.board.verify_path())
                            
                    if self.move["winners"] == "miners":
                        self.end_round(Role.MINER)
                        if self.current_round > 1:
                            self.move["match_status"] = "finished"

                    # Prepara o restante jogada
                    self.move["action"] = "build"
                    self.move["card_id"] = self.selected_card.get_id()
                    self.move["position"] = str(row) + str(col)

            elif self.selected_card.get_id()[0:2] == "01":
                if self.board.get_card_from_position(self.selected_position).is_destroyable():
                    self.resolve_turn()
                    self.board.remove_card_from_position([row, col])
                    
                    # Prepara o restante jogada
                    self.move["action"] = "destroy"
                    self.move["position"] = str(row) + str(col)

            elif self.selected_card.get_id()[0:2] == "02":
                card = self.board.get_card_from_position(self.selected_position)
                if not card.is_revealed():
                    self.resolve_turn()
                    card.reveal()

    def select_player_slot(self, player_index, slot_index):
        if self.is_local_player_turn() and self.selected_card != None:
            selected_player = self.players[player_index]
            if self.selected_card.get_id()[0:2] == "11" and not selected_player.is_slot_empty(slot_index):
                if selected_player.is_slot_blocked_by_one_of_these_tools(slot_index, self.selected_card.get_tools()):
                    self.resolve_turn()
                    selected_player.remove_sabotage_card(slot_index)
                    print("Carta de sabotagem removida!")

                    # Prepara o restante da jogada
                    self.move["action"] = "unblock"
                    self.move["slot_index"] = str(slot_index)
                    self.move["player_index"] = str(player_index)

            if self.selected_card.get_id()[0:2] == "10" and selected_player != self.local_player:
                print("Carta de sabotagem!")
                if not selected_player.has_this_sabotage_card(self.selected_card):
                    self.resolve_turn()
                    selected_player.add_sabotage_card(self.selected_card, slot_index)
                    print("Carta de sabotagem aplicada!")

                    # Prepara o restante da jogada
                    self.move["action"] = "block"
                    self.move["card_id"] = self.selected_card.get_id()
                    self.move["slot_index"] = str(slot_index)
                    self.move["player_index"] = str(player_index)

    def receive_move(self, move):
        print("Jogada recebida!")
        if move["winners"] == "saboteurs":
            self.distribute_gold(move)
        
        if move["action"] == "send_deck":
            self.reset_round()
            self.deck.from_string(move["deck"])
            self.deal_cards()
        else:
            if move["action"] == "build":
                position = [int(move["position"][0]), int(move["position"][1])]
                card = PathCard(move["card_id"])
                self.board.set_card_to_position(card, position)
                self.reveal_cards(self.board.verify_path()) # Adicionado agora
                if move["winners"] == "miners":
                    self.distribute_gold(move)

            elif move["action"] == "destroy":
                position = [int(move["position"][0]), int(move["position"][1])]
                self.board.remove_card_from_position(position)
            
            elif move["action"] == "block":
                card = Deck.card_factory(move["card_id"])
                player = self.players[int(move["player_index"])]
                slot_index = int(move["slot_index"])
                player.add_sabotage_card(card, slot_index)

            elif move["action"] == "unblock":
                player = self.players[int(move["player_index"])]
                slot_index = int(move["slot_index"])
                player.remove_sabotage_card(slot_index)

            if self.deck.size() > 0:
                self.deck.pop()
            self.toggle_turn()