from card import *
from enum import Enum

class Player:
    def __init__(self):
        self.name = ""
        self.selected_card = None
        self.hand = []
        self.role = None
        self.gold = 0
        self.sabotage_cards = [None, None, None]

    def initialize(self, player):
        self.name = player[0]
        self.id = player[1]
        self.position = int(player[2]) - 1

    def is_hand_empty(self):
        return len(self.hand) == 0

    def set_role(self, role):
        self.role = role

    def get_role(self):
        return self.role

    def add_gold(self, nuggets):
        self.gold += nuggets

    def get_gold(self):
        return self.gold

    def get_name(self):
        return self.name

    def get_position(self):
        return self.position

    def buy_card(self, card):
        self.hand.append(card)

    def get_hand(self):
        return self.hand

    def remove_card_from_hand(self, card):
        self.hand.remove(card)

    def clear_hand(self):
        self.hand.clear()

    def add_sabotage_card(self, card, slot_index):
        self.sabotage_cards[slot_index] = card

    def remove_sabotage_card(self, slot_index):
        self.sabotage_cards[slot_index] = None

    def get_sabotage_cards(self):
        return self.sabotage_cards

    def has_this_sabotage_card(self, card):
        id = card.get_id()
        for c in self.sabotage_cards:
            if c != None and c.get_id() == id:
                return True
        return False

    def is_slot_blocked_by_one_of_these_tools(self, slot_index, tools):
        card_tool = self.sabotage_cards[slot_index].get_tool()
        if card_tool in tools:
            return True
        return False

    def is_slot_empty(self, slot_index):
        return self.sabotage_cards[slot_index] == None

    def is_blocked(self):
        for i in range(3):
            if self.sabotage_cards[i] != None:
                return True
        return False

class Role(Enum):
    MINER = 1
    SABOTEUR = 2

    def value_to_string(self):
        return '%s' % self.value