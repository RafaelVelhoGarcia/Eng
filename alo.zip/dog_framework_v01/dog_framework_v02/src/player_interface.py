import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog
from dog.dog_interface import DogPlayerInterface
from dog.dog_actor import DogActor

from match import Match

CARD_WIDTH = 60
CARD_HEIGHT = 84

class Slot(tk.Label):
    def __init__(self, parent, width, height, callback=None, bg="white", relief=tk.RIDGE):
        self.blank_img = tk.PhotoImage(width=width, height=height)
        super().__init__(
            parent,
            image=self.blank_img,
            bd=1,
            relief=relief,
            bg=bg
        )
        self.image = self.blank_img  # keep reference?
        self.callback = callback
        if callback:
            self.bind("<Button-1>", self.on_click)
    
    def on_click(self, event):
        if self.callback:
            self.callback()
    
    def set_image(self, image):
        if image == None:
            self.config(image=self.blank_img)
        else:
            self.config(image=image)
            self.image = image  # Keep reference

class BoardFrame(tk.Frame):
    def __init__(self, parent, rows, cols, on_slot_click):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        self.slots = []
        
        for row in range(rows):
            row_slots = []
            for col in range(cols):
                slot = Slot(
                    self,
                    CARD_WIDTH,
                    CARD_HEIGHT,
                    callback=lambda r=row, c=col: on_slot_click(r, c),
                    bg="white"
                )
                slot.grid(row=row, column=col, padx=1, pady=1)
                row_slots.append(slot)
            self.slots.append(row_slots)

class HandFrame(tk.Frame):
    def __init__(self, parent, num_slots, on_slot_click):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        tk.Label(self, text="Mão", font=("Arial", 10)).pack()
        
        cards_container = tk.Frame(self)
        cards_container.pack()
        
        self.slots = []
        for i in range(num_slots):
            slot = Slot(
                cards_container,
                CARD_WIDTH,
                CARD_HEIGHT,
                callback=lambda idx=i: on_slot_click(idx),
                bg="white"
            )
            slot.pack(side=tk.LEFT, padx=2)
            self.slots.append(slot)

class DiscardFrame(tk.Frame):
    def __init__(self, parent, on_click):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        tk.Label(self, text="Descarte", font=("Arial", 10)).pack()
        self.slot = Slot(
            self,
            CARD_WIDTH,
            CARD_HEIGHT,
            callback=on_click,
            bg="white"
        )
        self.slot.pack()

class PlayerFrame(tk.Frame):
    def __init__(self, parent, player_id, on_slot_click):  # Modified to accept slot callback
        super().__init__(parent, bd=1, relief=tk.RIDGE, padx=2, pady=2)
        self.player_id = player_id
        
        self.label = tk.Label(self, text=f"Player {player_id+1} - Ouro: 0", font=("Arial", 10))
        self.label.pack()
        
        cards_frame = tk.Frame(self)
        cards_frame.pack(pady=1)
        
        self.card_slots = []
        for j in range(3):
            slot = Slot(
                cards_frame,
                CARD_WIDTH,
                CARD_HEIGHT,
                bg="lightgrey",
                relief=tk.SUNKEN
            )
            # Add click binding to each slot
            slot.bind("<Button-1>", 
                     lambda e, idx=j: on_slot_click(player_id, idx))
            slot.pack(side=tk.LEFT, padx=1)
            self.card_slots.append(slot)
    
    def update(self, name, gold):
        self.label.config(text=f" {name} - Ouro: {gold}")

    def update_sabotage_cards(self, sabotage_cards):
        for i in range(3):
            texture = PlayerInterface.get_texture(sabotage_cards[i])
            self.card_slots[i].set_image(texture)

class PlayerListFrame(tk.Frame):
    def __init__(self, parent, num_players, on_slot_click):  # Add slot callback
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        self.player_frames = []
        
        for i in range(num_players):
            player_frame = PlayerFrame(
                self, 
                i, 
                on_slot_click=on_slot_click  # Pass slot callback
            )
            player_frame.pack(pady=1, fill=tk.X)
            self.player_frames.append(player_frame)

    def update(self, players):
        for i in range(5):
            self.player_frames[i].update(players[i].get_name(), players[i].get_gold())

    def update_sabotage_cards(self, sabotage_cards):
        for i in range(5):
            self.player_frames[i].update_sabotage_cards(sabotage_cards[i])

class PlayerInterface(DogPlayerInterface, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Saboteur")
        self._create_menu()
        self._create_status()
        self._create_main_interface()
        self._initialize_game()
        self.match = Match() # Cria a partida vazia
    
    def _create_menu(self):
        menubar = tk.Menu(self)
        game_menu = tk.Menu(menubar, tearoff=0)
        game_menu.add_command(label="Start Match", command=self.start_match)
        game_menu.add_separator()
        game_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="Game", menu=game_menu)
        self.config(menu=menubar)
    
    def _create_status(self):
        self.status_text = "Partida não iniciada"
        self.status_label = tk.Label(self, text=self.status_text, font=("Arial", 12))
        self.status_label.pack(pady=2)
    
    def _create_main_interface(self):
        main_frame = tk.Frame(self)
        main_frame.pack(padx=5, pady=5)
        
        # Board
        self.board_frame = BoardFrame(main_frame, 5, 9, self.on_board_click)
        self.board_frame.pack(side=tk.LEFT, padx=2)
        
        # Player list
        self.player_list_frame = PlayerListFrame(
            main_frame, 
            5, 
            on_slot_click=self.on_player_slot_click  # Add slot callback
        )
        self.player_list_frame.pack(side=tk.LEFT, padx=2, fill=tk.Y)
        
        # Bottom area
        bottom_frame = tk.Frame(self)
        bottom_frame.pack(pady=5)
        
        # Hand
        self.hand_frame = HandFrame(bottom_frame, 6, self.on_hand_click)
        self.hand_frame.pack(side=tk.LEFT, padx=5)
        
        # Discard
        self.discard_frame = DiscardFrame(bottom_frame, self.on_discard_click)
        self.discard_frame.pack(side=tk.LEFT, padx=5)
    
    def _initialize_game(self):
        player_name = simpledialog.askstring("Player", "Qual o seu nome?")
        self.dog_server_interface = DogActor()
        message = self.dog_server_interface.initialize(player_name, self)
        messagebox.showinfo(message=message)
    
    def start_match(self):
        match_status = self.match.is_running()
        if match_status == False:
            start_status = self.dog_server_interface.start_match(5)
            code = start_status.get_code()
            message = start_status.get_message()
            if code == "0" or code == "1":
                messagebox.showinfo(message=message)
            else: # code == 2
                players = start_status.get_players()
                local_player_id = start_status.get_local_id()
                self.match.start(players, local_player_id)
                self.player_list_frame.update(self.match.get_players())
                self.match.start_round()
                self.dog_server_interface.send_move(self.match.get_move())
                self.update_board_frame()
                self.update_hand_frame()
                self.update_role_interface()
                messagebox.showinfo(message=start_status.get_message())

    def receive_start(self, start_status):
        print("Received Start!")
        players = start_status.get_players()
        local_player_id = start_status.get_local_id()
        self.match.start(players, local_player_id)
        self.player_list_frame.update(self.match.get_players())

    def receive_move(self, move):
        self.match.receive_move(move)
        self.update_role_interface()
        self.update_board_frame()
        self.update_hand_frame()
        self.player_list_frame.update_sabotage_cards(self.match.get_sabotage_cards()) # ISSO É APENAS UM TESTE

        if move["winners"] == "miners" or move["winners"] == "saboteurs":
            self.player_list_frame.update(self.match.get_players())
        
        if move["match_status"] == "finished":
            self.match.end()
            self.status_label.config(text="Match finished")

        if move["winners"] == None:
            if self.match.check_if_no_more_cards():
                move = self.match.get_move()
                self.match.distribute_gold(move)
                self.dog_server_interface.send_move(move)
            
    def update_role_interface(self):
        print("Updating role interface")
        self.status_label.config(text=f"You are a {self.match.get_local_player().get_role().name}!")

    def update_hand_frame(self):
        print("Atualizando interface da mão...")
        hand = self.match.get_local_player_hand()
        for i in range(len(hand)):
            texture = self.get_texture(hand[i])
            self.hand_frame.slots[i].set_image(texture)
        for i in range(len(hand), 6):
            self.hand_frame.slots[i].set_image(None)

    def update_board_frame(self):
        print("Atualizando interface do tabuleiro...")
        for i in range(5):
            for j in range(9):
                card = self.match.board.get_card_from_position([i, j])
                texture = self.get_texture(card)
                self.board_frame.slots[i][j].set_image(texture)

    @staticmethod
    def get_texture(card):
        if card == None:
            return None
        id = card.get_id()
        if id[0:2] == "03" or id[0:2] == "04":
            if not card.is_revealed():
                id = "03"
        return tk.PhotoImage(file="./card_textures/" + id + ".png")
    
    def on_board_click(self, row, col):
        match_status = self.match.is_running()
        if match_status == True:
            self.match.select_board_position(row, col)
            if self.match.is_move_valid() == True:
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)
                if move["winners"] == "miners":
                    self.update_board_frame()
                    self.update_hand_frame()
                    self.player_list_frame.update(self.match.get_players())
                    messagebox.showinfo(message="The miners won!")
                    if move["match_status"] == "finished":
                        self.match.end()
                        self.status_label.config(text="Match finished")
                    else:
                        self.match.start_round()
                        self.dog_server_interface.send_move(self.match.get_move())
                self.update_board_frame()
                self.update_hand_frame()
                self.player_list_frame.update_sabotage_cards(self.match.get_sabotage_cards())
                self.match.reset_move()
        
    def on_player_slot_click(self, player_id, slot_index):
        if self.match.is_running() == True:
            self.match.select_player_slot(player_id, slot_index)
            if self.match.is_move_valid() == True:
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)

                self.player_list_frame.update_sabotage_cards(self.match.get_sabotage_cards())
                self.update_hand_frame()
                self.match.reset_move()
    
    def on_hand_click(self, slot_index):
        if self.match.is_running() == True:
            self.match.select_hand_position(slot_index)
            self.update_hand_frame()
    
    def on_discard_click(self):
        if self.match.is_running() == True:
            self.match.discard()
            if self.match.is_move_valid():
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)
                print("Carta selecionada foi descartada")
                self.match.reset_move()
        self.update_hand_frame()