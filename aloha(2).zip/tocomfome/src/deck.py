import random
from card import *
from player import Role

class Deck:
    def __init__(self):
        self.deck = []

    # INSERIR METODO ABAIXO NO DIAGRAMA DE CLASSES
    @staticmethod
    def get_role_from_card_id(card_id):
        return Role(int(card_id[1]))

    def append(self, card):
        self.deck.append(card)

    def shuffle(self):
        random.shuffle(self.deck)

    # FIM DO QUE PRECISA SER INSERIDO

    # Sequencia OK
    def initialize(self):
        self.add_path_cards()
        self.add_map_cards()
        self.add_rockfall_cards()
        self.add_sabotage_cards()
        self.add_repair_cards()
        self.shuffle()
        self.add_goal_cards()
        self.add_role_cards()
    
    def pop(self):
        return self.deck.pop()

    def clear(self):
        self.deck.clear()

    def is_empty(self):
        return len(self.deck) == 0

    # Diagrama de algoritmo feito!
    def add_goal_cards(self):
        gold = random.randint(0, 2)
        for i in range(3):
            if i == gold:
                gold_str = "3"
            else:
                gold_str = "4"
            card = GoalCard("0" + gold_str + "11111", i == gold)
            self.append(card)

    # Diagrama de algoritmo feito!
    def add_role_cards(self):
        roles = ["1", "1", "1", "1", "2", "2"] # 4 miners, 2 saboteurs
        random.shuffle(roles)
        for i in range(5):
            card = Card("2" + roles[i])
            self.append(card)

    # Diagrama de algoritmo feito!
    def add_gold_nuggets_cards(self):
        nugget_list = []
        for i in range(4):
            nugget_list.append(3)
        for i in range(8):
            nugget_list.append(2)
        for i in range(16):
            nugget_list.append(1)

        random.shuffle(nugget_list)
        nugget_list = nugget_list[0:4]
        nugget_list.sort()

        self.clear()
        for i in range(4):
            card = GoldNuggetsCard("3" + str(nugget_list[i]))
            self.append(card)

    # Fazer diagrama de algoritmo
    def add_path_cards(self):
        for i in range(4):
            self.append(self.card_factory("0001011"))
        for i in range(5):
            self.append(self.card_factory("0011011"))
        for i in range(5): # Substituir pra 5 depois
            self.append(Deck.card_factory("0011111"))
        for i in range(5):
            self.append(self.card_factory("0011101"))
        for i in range(3):
            self.append(self.card_factory("0010101"))
        for i in range(4):
            self.append(self.card_factory("0010011"))
        for i in range(5):
            self.append(self.card_factory("0000111"))
        for i in range(4):
            self.append(self.card_factory("0000010"))
        self.append(self.card_factory("0001010"))
        self.append(self.card_factory("0011010"))
        self.append(self.card_factory("0011110"))
        self.append(self.card_factory("0011100"))
        self.append(self.card_factory("0010100"))
        self.append(self.card_factory("0010010"))
        self.append(self.card_factory("0000110"))
        self.append(self.card_factory("0000100"))

    # Fazer diagrama de algoritmo
    def add_map_cards(self):
        for i in range(6):
            self.append(Card("02"))

    # Fazer diagrama de algoritmo
    def add_rockfall_cards(self): 
        for i in range(3): # MUDAR PARA 3
            self.append(Card("01"))

    # Fazer diagrama de algoritmo
    def add_sabotage_cards(self):
        for i in range(3): # PADRAO - 3
            self.append(Deck.card_factory("101"))
            self.append(Deck.card_factory("102"))
            self.append(Deck.card_factory("103"))

    # Fazer diagrama de algoritmo
    def add_repair_cards(self):
        for i in range(2): #PADRAO = 2
            self.append(Deck.card_factory("111"))
            self.append(Deck.card_factory("112"))
            self.append(Deck.card_factory("113"))
        self.append(Deck.card_factory("114"))
        self.append(Deck.card_factory("115"))
        self.append(Deck.card_factory("116"))

    # Diagrama de algoritmo feito!
    @staticmethod
    def card_factory(id):
        if id[0] == "0": 
            if id[1] == "0":
                return PathCard(id)
            if (id[1] == "1" or id[1] == "2"):
                return Card(id)
            if id[1] == "3":
                return GoalCard(id, True)
            elif id[1] == "4":
                return GoalCard(id, False)
        elif id[0] == "1":
            if id[1] == "0":
                if id[2] == "1":
                    return SabotageCard(id, Tool.MINECART)
                elif id[2] == "2":
                    return SabotageCard(id, Tool.LANTERN)
                elif id[2] == "3":
                    return SabotageCard(id, Tool.PICKAXE)
            elif id[1] == "1":
                if id[2] == "1":
                    return RepairCard(id, [Tool.MINECART])
                elif id[2] == "2":
                    return RepairCard(id, [Tool.LANTERN])
                elif id[2] == "3":
                    return RepairCard(id, [Tool.PICKAXE])
                if id[2] == "4":
                    return RepairCard(id, [Tool.MINECART, Tool.LANTERN])
                if id[2] == "5":
                    return RepairCard(id, [Tool.LANTERN, Tool.PICKAXE])
                if id[2] == "6":
                    return RepairCard(id, [Tool.MINECART, Tool.PICKAXE])
        elif id[0] == "2":
            return Card(id)
        elif id[0] == "3":
            return GoldNuggetsCard(id)

    # Fazer diagrama de algoritmo
    def to_string(self):
        deck_str = []
        for card in self.deck:
            card_id = card.get_id()
            deck_str.append(card_id)
        return deck_str

    # Fazer diagrama de algoritmo
    def from_string(self, deck_str):
        for card_id in deck_str:
            card = Deck.card_factory(card_id)
            self.append(card)