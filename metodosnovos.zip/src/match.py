from player import *
import random
from enum import Enum
from card import *
from collections import deque
from deck import Deck
from board import Board

class Match:
    def __init__(self):
        self.local_player = None
        self.current_player_index = None
        self.local_player_index = None
        self.selected_card = None
        self.deck = Deck()
        self.players = []
        self.board = Board()
        self.move = {"action" : None, "match_status" : None, "deck" : None, "winners" : None, "card_id" : None, "player_index" : None, "slot_index" : None}
        self.valid_move = False
        self.current_round = 0
        for i in range(5):
            self.players.append(Player())
        self.running = False     # Nenhuma partida em andamento
        self.hand = []

    # ADICIONAR NOS DIAGRAMAS
    @staticmethod
    def dog_index_to_player_index(dog_index):
        return int(dog_index) - 1

    def reset_current_player_index(self):
        self.current_player_index = 0

    def reset_current_round(self):
        self.current_round = 0

    def set_local_player(self, player):
        self.local_player = player

    @staticmethod
    def position_to_string(position):
        return str(position[0]) + str(position[1])

    @staticmethod
    def string_to_position(string):
        return [int(string[0]), int(string[1])]

    @staticmethod
    def string_to_int(string):
        return int(string)

    @staticmethod
    def int_to_string(int_):
        return str(int_)

    def set_move_action(self, action):
        self.move["action"] = action

    def set_move_match_status(self, match_status):
        self.move["match_status"] = match_status

    def set_move_deck(self, deck):
        self.move["deck"] = deck

    def set_move_winners(self, winners):
        self.move["winners"] = winners

    def set_move_card_id(self, card_id):
        self.move["card_id"] = card_id

    def set_move_player_index(self, player_index):
        self.move["player_index"] = str(player_index)

    def set_move_slot_index(self, slot_index):
        self.move["slot_index"] = str(slot_index)

    def set_move_as_valid(self):
        self.valid_move = True

    def set_selected_card(self, card):
        self.selected_card = card

    def sort_players(self):
        self.players = sorted(self.players, key=lambda idx: idx.index)

    def increment_round(self):
        self.current_round += 1
    # FIM DO QUE PRECISA SER ADICIONADO

    def get_hand(self):
        return self.hand

    def get_move(self):
        return self.move

    def is_running(self):
        return self.running

    def get_players(self):
        return self.players

    def get_local_player_role(self):
        return self.local_player.get_role()

    def is_move_valid(self):
        return self.valid_move

    def is_local_player_turn(self):
        return self.local_player_index == self.current_player_index

    def reset_move(self):
        self.move = {"action" : None, "match_status" : None, "deck" : None, "winners" : None, "card_id" : None, "player_index" : None, "slot_index" : None}
        self.valid_move = False

    def toggle_turn(self):
        self.current_player_index = (self.current_player_index + 1) % 5

    def get_current_player(self):
        return self.players[self.current_player_index]

    # Antes de realizar a troca de turno, o método abaixo gasta a carta utilizada na jogada e compra uma nova. A jogada também é marcada como válida
    def resolve_turn(self):
        self.hand.remove(self.selected_card)
        self.buy_card()
        self.set_move_as_valid()
        self.toggle_turn()
        self.set_move_match_status("next")

    def reset_round(self):
        self.selected_card = None
        self.hand.clear()
        self.deck.clear()
        self.board.clear()
        self.reset_move()
        self.increment_round()

    def start_round(self):
        if self.current_round == 3:
            self.end()
            self.set_move_match_status("finished")
        else:
            self.reset_round()
            self.send_deck()
            self.deal_cards()
            self.toggle_turn()

    def miners_win(self):
        self.deck.add_gold_cards()
        deck_str = self.deck.to_string()
        self.set_move_deck(deck_str)
        self.distribute_gold(self.move)

    def end(self):
        self.running = False
    
    def get_teams_in_order(self):
        miners = []
        saboteurs = []
        for i in range(5):
            player = self.players[((self.current_player_index + i) % 5)]
            role = player.get_role()
            if role == Role.SABOTEUR:
                saboteurs.append(player)
            else:
                miners.append(player)
        return miners, saboteurs

    def distribute_gold(self, move):
        miners, saboteurs = self.get_teams_in_order()

        if move["winners"] == "miners":
            self.deck.from_string(move["deck"])
            for miner in miners:
                card = self.deck.pop()
                nuggets = card.get_gold()
                miner.add_gold(nuggets)

        if move["winners"] == "saboteurs":
            if len(saboteurs) == 2:
                saboteurs[0].add_gold(3)
                saboteurs[1].add_gold(3)
            else:
                saboteurs[0].add_gold(4)

    def no_more_cards(self):
        if len(self.hand) == 0:
            self.set_move_winners("saboteurs")
            self.toggle_turn()
            if self.current_round == 3:
                self.set_move_match_status("finished")
            else:
                self.set_move_match_status("next")
            self.distribute_gold(self.move)
            return True
        return False

    def select_hand_position(self, index):
        player_turn = self.is_local_player_turn()
        if player_turn and index < len(self.hand):
            if self.selected_card == self.hand[index]:
                card_id = self.selected_card.get_id()
                if card_id[0:2] == "00":
                    self.selected_card.rotate()
            self.set_selected_card(self.hand[index])

    def initialize(self, players, local_player_id):
        self.running = True     # Em progresso
        for i in range(5):
            self.players[i].initialize(players[i])
            if players[i][1] == local_player_id:
                self.set_local_player(self.players[i])
                self.local_player_index = Match.dog_index_to_player_index(players[i][2])

        self.sort_players()
        self.reset_current_player_index()
        self.reset_current_round()

    def send_deck(self):
        self.deck.initialize()
        self.set_move_action("send_deck")
        self.set_move_match_status("next")
        deck_str = self.deck.to_string()
        self.set_move_deck(deck_str)

    def deal_cards(self):
        for player in self.players:
            card = self.deck.pop()
            card_id = card.get_id()
            role = Deck.get_role_from_card_id(card_id)
            player.set_role(role)
        card = self.deck.pop()
        self.board.set_card_to_position(card, [0, 8])
        card = self.deck.pop()
        self.board.set_card_to_position(card, [2, 8])
        card = self.deck.pop()
        self.board.set_card_to_position(card, [4, 8])

        for i in range(5):
            if i == self.local_player_index:
                for j in range(6):
                    card = self.deck.pop()
                    self.hand.append(card)
            else:
                for j in range(6):
                    self.deck.pop()

        card = PathCard("0011111", False)
        self.board.set_card_to_position(card, [2, 0])

    def buy_card(self):
        empty = self.deck.is_empty()
        if not empty:
            card = self.deck.pop()
            self.hand.append(card)

    def discard(self):
        player_turn = self.is_local_player_turn()
        if player_turn and self.selected_card != None:
            self.resolve_turn()

    def reveal_cards(self, cards):
        for c in cards:
            is_card_revealed = c.is_revealed()
            if not is_card_revealed:
                c.reveal()
            card_has_gold = c.has_gold()
            if card_has_gold:
                self.set_move_winners("miners")

    def select_board_position(self, position):
        player_turn = self.is_local_player_turn()
        if player_turn and self.selected_card != None:
            card_id = self.selected_card.get_id()
            broken_tool = self.local_player.has_broken_tool()
            if card_id[0:2] == "00" and not broken_tool:
                valid_adjacency = self.board.check_adjacent_cards(self.selected_card, position)
                valid_path = self.board.verify_path_to_target(position, self.selected_card)
                if valid_adjacency and valid_path:
                    self.resolve_turn()
                    self.board.set_card_to_position(self.selected_card, position)

                    reached_goal_cards = self.board.verify_path()
                    self.reveal_cards(reached_goal_cards)
                            
                    if self.move["winners"] == "miners":
                        self.miners_win()
                        self.set_move_match_status("progress")

                    # Prepara o restante jogada
                    self.set_move_action("build")
                    card_id = self.selected_card.get_id()
                    self.set_move_card_id(card_id)
                    position_str = Match.position_to_string(position)
                    self.set_move_slot_index(position_str)

            elif card_id[0:2] == "01":
                card = self.board.get_card_from_position(position)
                destroyable = card.is_destroyable()
                if destroyable:
                    self.resolve_turn()
                    self.board.remove_card_from_position(position)
                    
                    # Prepara o restante jogada
                    self.set_move_action("destroy")
                    position_str = Match.position_to_string(position)
                    self.set_move_slot_index(position_str)

            elif card_id[0:2] == "02":
                card = self.board.get_card_from_position(position)
                revealed = card.is_revealed()
                if not revealed:
                    self.resolve_turn()
                    card.reveal()

    def select_player_slot(self, player_index, slot_index):
        player_turn = self.is_local_player_turn()
        if player_turn and self.selected_card != None:
            selected_player = self.players[player_index]
            card_id = self.selected_card.get_id()
            if card_id[0:2] == "11":
                tools = self.selected_card.get_tools()
                valid_slot = selected_player.does_slot_contain_one_of_these_tools(slot_index, tools)
                if valid_slot:
                    self.resolve_turn()
                    selected_player.remove_sabotage_card(slot_index)

                    # Prepara o restante da jogada
                    self.set_move_action("unblock")
                    self.set_move_slot_index(slot_index)
                    self.set_move_player_index(player_index)

            elif card_id[0:2] == "10" and selected_player != self.local_player:
                tool = self.selected_card.get_tool()
                broken_tool = selected_player.is_tool_broken(tool)
                if not broken_tool:
                    self.resolve_turn()
                    selected_player.add_sabotage_card(self.selected_card, slot_index)

                    # Prepara o restante da jogada
                    self.set_move_action("block")
                    card_id = self.selected_card.get_id()
                    self.set_move_card_id(card_id)
                    self.set_move_slot_index(slot_index)
                    self.set_move_player_index(player_index)

    def receive_move(self, move):
        self.toggle_turn()
        player_turn = self.is_local_player_turn()

        if move["match_status"] == "finished":
            self.end()

        if move["winners"] != None:
            self.distribute_gold(move)
        elif player_turn:
            if move["action"] != "send_deck":
                if self.no_more_cards():
                    return True
        
        if move["action"] == "send_deck":
            self.reset_round()
            self.deck.from_string(move["deck"])
            self.deal_cards()
        elif move["action"] != None:
            if move["action"] == "build":
                position = position = Match.string_to_position(move["slot_index"])
                card = PathCard(move["card_id"])
                self.board.set_card_to_position(card, position)
                reached_goal_cards = self.board.verify_path()
                self.reveal_cards(reached_goal_cards) 

            elif move["action"] == "destroy":
                position = Match.string_to_position(move["slot_index"])
                self.board.remove_card_from_position(position)
            
            elif move["action"] == "block":
                card = Deck.card_factory(move["card_id"])
                player_index = Match.string_to_int(move["player_index"])
                player = self.players[player_index]
                slot_index = Match.string_to_int(move["slot_index"])
                player.add_sabotage_card(card, slot_index)

            elif move["action"] == "unblock":
                player_index = Match.string_to_int(move["player_index"])
                player = self.players[player_index]
                slot_index = Match.string_to_int(move["slot_index"])
                player.remove_sabotage_card(slot_index)

            is_deck_empty = self.deck.is_empty()
            if not is_deck_empty:
                self.deck.pop()
        return False

    # Adicionar no diagrama de classes!
    def get_board(self):
        return self.board.get_board()