from card import *
from enum import Enum

class Player:
    def __init__(self):
        self.name = ""
        self.role = None
        self.gold_qtd = 0
        self.sabotage_cards = [None, None, None]

    def initialize(self, player):
        self.name = player[0]
        self.id = player[1]
        self.index = int(player[2]) - 1

    def set_role(self, role):
        self.role = role

    def get_role(self):
        return self.role

    def add_gold(self, nuggets):
        self.gold_qtd += nuggets

    def get_gold(self):
        return self.gold_qtd

    def get_name(self):
        return self.name

    def add_sabotage_card(self, card, index):
        self.sabotage_cards[index] = card

    def remove_sabotage_card(self, index):
        self.sabotage_cards[index] = None

    def get_sabotage_cards(self):
        return self.sabotage_cards

    def is_tool_broken(self, tool):
        for c in self.sabotage_cards:
            if c != None and c.get_tool() == tool:
                return True
        return False

    def does_slot_contain_one_of_these_tools(self, index, tools):
        if self.sabotage_cards[index] == None:
            return False
        card_tool = self.sabotage_cards[index].get_tool()
        if card_tool in tools:
            return True
        return False

    def is_slot_empty(self, slot_index):
        return self.sabotage_cards[slot_index] == None

    def has_broken_tool(self):
        for i in range(3):
            if self.sabotage_cards[i] != None:
                return True
        return False

class Role(Enum):
    MINER = 1
    SABOTEUR = 2

    def value_to_string(self):
        return '%s' % self.value