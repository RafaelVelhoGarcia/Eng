# Saboteur

## Instruções de execução

1. Ir para a pasta src (cd src)
2. Nesta pasta, execute virtualenv venv
3. Ative a virtualenv: venv\Scripts\activate
4. Rode `pip install -r requirements.txt`.
5. Executar o programa (python3 main.py)
6. Abra outros 4 terminais e execute o mesmo comando