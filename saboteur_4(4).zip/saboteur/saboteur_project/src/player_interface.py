import tkinter as tk
from tkinter import messagebox
from tkinter import simpledialog
from dog.dog_interface import DogPlayerInterface
from dog.dog_actor import DogActor

from match import Match

CARD_WIDTH = 60
CARD_HEIGHT = 84

class Slot(tk.Label):
    def __init__(self, parent, width, height, bg="white", relief=tk.RIDGE):
        self.blank_img = tk.PhotoImage(width=width, height=height)
        super().__init__(
            parent,
            image=self.blank_img,
            bd=1,
            relief=relief,
            bg=bg
        )
        self.image = self.blank_img
        self.parent_component = None  # Will be set by parent
        self.slot_id = None  # Will be set by parent
    
    def set_parent_component(self, parent_component, slot_id):
        self.parent_component = parent_component
        self.slot_id = slot_id
        self.bind("<Button-1>", self.on_click)
    
    def on_click(self, event):
        self.parent_component.handle_slot_click(self.slot_id)
    
    def set_image(self, image):
        if image == None:
            self.config(image=self.blank_img)
        else:
            self.config(image=image)
            self.image = image

class BoardFrame(tk.Frame):
    def __init__(self, parent, rows, cols):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        self.slots = []
        self.game_interface = None  # Will be set by PlayerInterface
        
        for row in range(rows):
            row_slots = []
            for col in range(cols):
                slot = Slot(self, CARD_WIDTH, CARD_HEIGHT, bg="white")
                slot.set_parent_component(self, (row, col))
                slot.grid(row=row, column=col, padx=1, pady=1)
                row_slots.append(slot)
            self.slots.append(row_slots)
    
    def set_game_interface(self, game_interface):
        self.game_interface = game_interface
    
    def handle_slot_click(self, slot_id):
        if self.game_interface:
            row, col = slot_id
            self.game_interface.select_board_position([row, col])

    def update(self, board):
        for i in range(5):
            for j in range(9):
                texture = PlayerInterface.get_texture(board[i][j])
                self.slots[i][j].set_image(texture)

class HandFrame(tk.Frame):
    def __init__(self, parent, num_slots):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        tk.Label(self, text="Mão", font=("Arial", 10)).pack()
        
        cards_container = tk.Frame(self)
        cards_container.pack()
        
        self.slots = []
        self.game_interface = None
        
        for i in range(num_slots):
            slot = Slot(cards_container, CARD_WIDTH, CARD_HEIGHT, bg="white")
            slot.set_parent_component(self, i)
            slot.pack(side=tk.LEFT, padx=2)
            self.slots.append(slot)
    
    def set_game_interface(self, game_interface):
        self.game_interface = game_interface
    
    def handle_slot_click(self, slot_id):
        if self.game_interface:
            self.game_interface.select_hand_position(slot_id)

    def update(self, hand):
        for i in range(len(hand)):
            texture = PlayerInterface.get_texture(hand[i])
            self.slots[i].set_image(texture)
        for i in range(len(hand), 6):
            self.slots[i].set_image(None)

class DiscardFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        tk.Label(self, text="Descarte", font=("Arial", 10)).pack()
        self.slot = Slot(self, CARD_WIDTH, CARD_HEIGHT, bg="white")
        self.slot.set_parent_component(self, "discard")
        self.slot.pack()
        self.game_interface = None
    
    def set_game_interface(self, game_interface):
        self.game_interface = game_interface
    
    def handle_slot_click(self, slot_id):
        if self.game_interface:
            self.game_interface.select_discard_pile()

class PlayerFrame(tk.Frame):
    def __init__(self, parent, player_id):
        super().__init__(parent, bd=1, relief=tk.RIDGE, padx=2, pady=2)
        self.player_id = player_id
        self.game_interface = None
        
        self.label = tk.Label(self, text=f"Player {player_id+1} - Ouro: 0", font=("Arial", 10))
        self.label.pack()
        
        cards_frame = tk.Frame(self)
        cards_frame.pack(pady=1)
        
        self.card_slots = []
        for j in range(3):
            slot = Slot(cards_frame, CARD_WIDTH, CARD_HEIGHT, bg="lightgrey", relief=tk.SUNKEN)
            slot.set_parent_component(self, j)
            slot.pack(side=tk.LEFT, padx=1)
            self.card_slots.append(slot)
    
    def set_game_interface(self, game_interface):
        self.game_interface = game_interface
    
    def handle_slot_click(self, slot_id):
        if self.game_interface:
            self.game_interface.select_player_slot(self.player_id, slot_id)
    
    def update_player_info(self, name, gold):
        self.label.config(text=f" {name} - Ouro: {gold}")

    def update_sabotage_cards(self, sabotage_cards):
        for i in range(3):
            texture = PlayerInterface.get_texture(sabotage_cards[i])
            self.card_slots[i].set_image(texture)

class PlayerListFrame(tk.Frame):
    def __init__(self, parent, num_players):
        super().__init__(parent, bd=1, relief=tk.GROOVE)
        self.player_frames = []
        self.game_interface = None
        
        for i in range(num_players):
            player_frame = PlayerFrame(self, i)
            player_frame.pack(pady=1, fill=tk.X)
            self.player_frames.append(player_frame)
    
    def set_game_interface(self, game_interface):
        self.game_interface = game_interface
        for player_frame in self.player_frames:
            player_frame.set_game_interface(game_interface)

    def update(self, players):
        for i in range(5):
            sabotage_cards = players[i].get_sabotage_cards()
            name = players[i].get_name()
            gold = players[i].get_gold()

            self.player_frames[i].update_sabotage_cards(sabotage_cards)
            self.player_frames[i].update_player_info(name, gold)

class PlayerInterface(DogPlayerInterface, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Saboteur")
        self._create_menu()
        self._create_status()
        self._create_main_interface()
        self._setup_component_references()
        self.match = Match()
        self._initialize_game()
    
    def _create_menu(self):
        menubar = tk.Menu(self)
        game_menu = tk.Menu(menubar, tearoff=0)
        game_menu.add_command(label="Start Match", command=self.start_match)
        game_menu.add_separator()
        game_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="Game", menu=game_menu)
        self.config(menu=menubar)
    
    def _create_status(self):
        self.status_text = "Partida não iniciada"
        self.status_label = tk.Label(self, text=self.status_text, font=("Arial", 12))
        self.status_label.pack(pady=2)
    
    def _create_main_interface(self):
        main_frame = tk.Frame(self)
        main_frame.pack(padx=5, pady=5)
        
        # Board
        self.board_frame = BoardFrame(main_frame, 5, 9)
        self.board_frame.pack(side=tk.LEFT, padx=2)
        
        # Player list
        self.player_list_frame = PlayerListFrame(main_frame, 5)
        self.player_list_frame.pack(side=tk.LEFT, padx=2, fill=tk.Y)
        
        # Bottom area
        bottom_frame = tk.Frame(self)
        bottom_frame.pack(pady=5)
        
        # Hand
        self.hand_frame = HandFrame(bottom_frame, 6)
        self.hand_frame.pack(side=tk.LEFT, padx=5)
        
        # Discard
        self.discard_frame = DiscardFrame(bottom_frame)
        self.discard_frame.pack(side=tk.LEFT, padx=5)
    
    def _setup_component_references(self):
        """Set up bidirectional references between components and main interface"""
        self.board_frame.set_game_interface(self)
        self.hand_frame.set_game_interface(self)
        self.discard_frame.set_game_interface(self)
        self.player_list_frame.set_game_interface(self)
    
    def _initialize_game(self):
        player_name = simpledialog.askstring("Player", "Qual o seu nome?")
        self.dog_server_interface = DogActor()
        message = self.dog_server_interface.initialize(player_name, self)
        messagebox.showinfo(message=message)
    
    # Game action methods - these replace the callback functions
    def select_board_position(self, position):
        running = self.match.is_running()
        if running == True:
            self.match.select_board_position(position)
            valid_move = self.match.is_move_valid()
            if valid_move:
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)
                if move["winners"] == "miners":
                    self.update_interface()
                    messagebox.showinfo(message="The miners won!")
                    self.match.start_round()
                    move = self.match.get_move()
                    self.dog_server_interface.send_move(move)
                self.update_interface()
                self.match.reset_move()
        
    def select_player_slot(self, player_index, slot_index):
        running = self.match.is_running()
        if running:
            self.match.select_player_slot(player_index, slot_index)
            valid_move = self.match.is_move_valid()
            if valid_move:
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)
                self.update_interface()
                self.match.reset_move()
    
    def select_hand_position(self, slot_index):
        running =  self.match.is_running()
        if running:
            self.match.select_hand_position(slot_index)
            hand = self.match.get_hand()
            self.hand_frame.update(hand)
    
    def select_discard_pile(self):
        running = self.match.is_running()
        if running:
            self.match.discard()
            valid_move = self.match.is_move_valid()
            if valid_move:
                move = self.match.get_move()
                self.dog_server_interface.send_move(move)
                self.match.reset_move()
                self.update_interface()
    
    def start_match(self):
        running = self.match.is_running()
        if not running:
            start_status = self.dog_server_interface.start_match(5)
            code = start_status.get_code()
            message = start_status.get_message()
            if code == "0" or code == "1":
                messagebox.showinfo(message=message)
            else:
                players = start_status.get_players()
                local_player_id = start_status.get_local_id()
                self.match.initialize(players, local_player_id)
                self.match.start_round()
                self.dog_server_interface.send_move(self.match.get_move())
                self.update_interface()
                messagebox.showinfo(message=start_status.get_message())

    def receive_start(self, start_status):
        players = start_status.get_players()
        local_player_id = start_status.get_local_id()
        self.match.initialize(players, local_player_id)

    def receive_move(self, move):
        saboteurs_win = self.match.receive_move(move)
        self.update_interface()

        if saboteurs_win == True:
            messagebox.showinfo(message="The saboteurs won!")
            self.match.start_round()
            move = self.match.get_move()
            move["winners"] = "saboteurs"
            self.dog_server_interface.send_move(move)
            self.update_interface()
            
    def update_role_interface(self):
        self.status_label.config(text=f"You are a {self.match.get_local_player_role().name}! - Player Turn: {self.match.get_current_player().name}")

    @staticmethod
    def get_texture(card):
        if card == None:
            return None
        id = card.get_id()
        if id[0:2] == "03" or id[0:2] == "04":
            if not card.is_revealed():
                id = "03"
        return tk.PhotoImage(file="./card_textures/" + id + ".png")

    def update_interface(self):
        self.update_role_interface()
        board = self.match.get_board()
        self.board_frame.update(board)
        hand = self.match.get_hand()
        self.hand_frame.update(hand)
        players = self.match.get_players()
        self.player_list_frame.update(players)
        running = self.match.is_running()
        if not running:
            self.status_label.config(text="Match finished")

    def receive_withdrawal_notification(self):
        self.match.end()
        self.status_label.config(text="Player abandoned the match")
